from django.apps import AppConfig


class MediaProjectConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'media_project'
